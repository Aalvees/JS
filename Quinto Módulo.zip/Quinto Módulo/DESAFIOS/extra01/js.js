var salario = window.prompt("Digite seu salário bruto de aprendiz")
document.write(`<h1> INSS desconta R$${salario*0.075} do seu salário de R$${salario}. Portanto seu salário liquido é de R$${salario*0.915}! <br>`)
document.write(`Você custa cerca de R$${salario*2.5} Para a sua empresa! <br>`)
document.write(`Achou caro? <br> Ou será que você sente que está ganhando pouca grana?`)