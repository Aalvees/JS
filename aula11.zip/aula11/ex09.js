var país = 'EUA'
console.log(`Vivendo em ${país}`)
if (país == 'Brasil') {
    console.log(`Você é Brasileiro!`)
} else {
    console.log('Você é estrangeiro!')
}