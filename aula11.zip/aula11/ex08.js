var vel = 60.5
console.log(`A velocidade do seu carro é ${vel}Km/h`)
if (vel > 60) { //CONDIÇÃO SIMPLES 
    console.log(`Você ultrapassou a velocidade permitida, MULTADO!`)
}
console.log(`Dirija sempre usando o cinto de segurança!`)